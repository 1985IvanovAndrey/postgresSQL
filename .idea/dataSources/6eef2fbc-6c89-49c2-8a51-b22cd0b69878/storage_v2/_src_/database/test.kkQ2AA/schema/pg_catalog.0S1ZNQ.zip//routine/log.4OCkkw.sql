CREATE FUNCTION log(numeric)
  RETURNS numeric
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.log(10, $1)
$$;

