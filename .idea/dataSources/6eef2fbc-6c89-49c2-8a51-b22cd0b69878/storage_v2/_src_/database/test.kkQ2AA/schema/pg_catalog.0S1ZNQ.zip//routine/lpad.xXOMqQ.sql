CREATE FUNCTION lpad(text, integer)
  RETURNS text
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.lpad($1, $2, ' ')
$$;

